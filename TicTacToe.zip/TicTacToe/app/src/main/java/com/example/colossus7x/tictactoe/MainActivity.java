package com.example.colossus7x.tictactoe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //all of the buttons
    Button btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven, btnEight, btnNine;

    //List for all of the buttons to be in
    Button[] myButtons = new Button[9];

    //counter to count what step we are on
    int counter = 0;
    int mCounter = 0;

    //variable for the text of button clicked
    CharSequence btnText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linking buttons
        btnOne = (Button) findViewById(R.id.btnOne);
        btnTwo = (Button) findViewById(R.id.btnTwo);
        btnThree = (Button) findViewById(R.id.btnThree);
        btnFour = (Button) findViewById(R.id.btnFour);
        btnFive = (Button) findViewById(R.id.btnFive);
        btnSix = (Button) findViewById(R.id.btnSix);
        btnSeven = (Button) findViewById(R.id.btnSeven);
        btnEight = (Button) findViewById(R.id.btnEight);
        btnNine = (Button) findViewById(R.id.btnNine);

        //putting buttons into array
        myButtons[0] = btnOne;
        myButtons[1] = btnTwo;
        myButtons[2] = btnThree;
        myButtons[3] = btnFour;
        myButtons[4] = btnFive;
        myButtons[5] = btnSix;
        myButtons[6] = btnSeven;
        myButtons[7] = btnEight;
        myButtons[8] = btnNine;

    }//end of onCreate

    //button to start a new game
    public void won(View v){
        int counter = 0;
        int mCounter = 0;

        for(int i = 0; i < myButtons.length; i++){
            myButtons[i].setText("");
            myButtons[i].setEnabled(true);
        }

        Toast.makeText(this, "Time to start a new game!", Toast.LENGTH_SHORT).show();
    }

    //check on if cat won or not
    public void cat(){
        //checking to see if the cat won
        if(myButtons[0].isEnabled() == false && myButtons[1].isEnabled() == false &&myButtons[2].isEnabled() == false &&
                myButtons[3].isEnabled() == false &&myButtons[4].isEnabled() == false &&myButtons[5].isEnabled() == false &&
                myButtons[6].isEnabled() == false &&myButtons[7].isEnabled() == false &&myButtons[8].isEnabled() == false){
            int counter = 0;
            int mCounter = 0;

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setText("");
                myButtons[i].setEnabled(true);
            }

            Toast.makeText(this, "The cat won!", Toast.LENGTH_SHORT).show();
        }//end of if statement

    }

    public void btnOneHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[0].setText("X");
        }else{
            myButtons[0].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[0].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[0].getText();
        if((myButtons[0].getText() == btnText && myButtons[1].getText() == btnText && myButtons[2].getText() == btnText)
                || (myButtons[0].getText() == btnText && myButtons[3].getText() == btnText && myButtons[6].getText() == btnText)
                || (myButtons[0].getText() == btnText && myButtons[4].getText() == btnText && myButtons[8].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop
        }//end of if statement
        else{
            cat();
            counter++;
        }//end of else statement

    }//end of btnOneHandler

    public void btnTwoHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[1].setText("X");
        }else{
            myButtons[1].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[1].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[1].getText();
        if((myButtons[1].getText() == btnText && myButtons[0].getText() == btnText && myButtons[2].getText() == btnText)
                || (myButtons[1].getText() == btnText && myButtons[4].getText() == btnText && myButtons[7].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();
            counter++;
        }//end of else statement

    }//end of btnTwoHandler

    public void btnThreeHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[2].setText("X");
        }else{
            myButtons[2].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[2].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[2].getText();
        if((myButtons[2].getText() == btnText && myButtons[1].getText() == btnText && myButtons[0].getText() == btnText)
                || (myButtons[2].getText() == btnText && myButtons[5].getText() == btnText && myButtons[8].getText() == btnText)
                || (myButtons[2].getText() == btnText && myButtons[4].getText() == btnText && myButtons[6].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnThreeHandler

    public void btnFourHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[3].setText("X");
        }else{
            myButtons[3].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[3].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[3].getText();
        if((myButtons[3].getText() == btnText && myButtons[0].getText() == btnText && myButtons[6].getText() == btnText)
                || (myButtons[3].getText() == btnText && myButtons[4].getText() == btnText && myButtons[5].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnFourHandler

    public void btnFiveHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[4].setText("X");
        }else{
            myButtons[4].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[4].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[4].getText();
        if((myButtons[4].getText() == btnText && myButtons[1].getText() == btnText && myButtons[7].getText() == btnText)
                || (myButtons[4].getText() == btnText && myButtons[3].getText() == btnText && myButtons[5].getText() == btnText)
                || (myButtons[4].getText() == btnText && myButtons[0].getText() == btnText && myButtons[8].getText() == btnText)
                || (myButtons[4].getText() == btnText && myButtons[2].getText() == btnText && myButtons[6].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnFiveHandler

    public void btnSixHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[5].setText("X");
        }else{
            myButtons[5].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[5].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[5].getText();
        if((myButtons[5].getText() == btnText && myButtons[2].getText() == btnText && myButtons[8].getText() == btnText)
                || (myButtons[5].getText() == btnText && myButtons[3].getText() == btnText && myButtons[4].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnSixHandler

    public void btnSevenHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[6].setText("X");
        }else{
            myButtons[6].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[6].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[6].getText();
        if((myButtons[6].getText() == btnText && myButtons[0].getText() == btnText && myButtons[3].getText() == btnText)
                || (myButtons[6].getText() == btnText && myButtons[4].getText() == btnText && myButtons[2].getText() == btnText)
                || (myButtons[6].getText() == btnText && myButtons[7].getText() == btnText && myButtons[8].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnSevenHandler

    public void btnEightHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[7].setText("X");
        }else{
            myButtons[7].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[7].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[7].getText();
        if((myButtons[7].getText() == btnText && myButtons[4].getText() == btnText && myButtons[1].getText() == btnText)
                || (myButtons[7].getText() == btnText && myButtons[6].getText() == btnText && myButtons[8].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnEightHandler

    public void btnNineHandler(View v){
        mCounter = counter%2;

        // if/else statement to decide on X or O
        if(mCounter == 0){
            myButtons[8].setText("X");
        }else{
            myButtons[8].setText("O");
        }//end of if/else statement

        //set button to false
        myButtons[8].setEnabled(false);

        //deciding on whether won or not
        btnText = myButtons[8].getText();
        if((myButtons[8].getText() == btnText && myButtons[7].getText() == btnText && myButtons[6].getText() == btnText)
                || (myButtons[8].getText() == btnText && myButtons[2].getText() == btnText && myButtons[5].getText() == btnText)
                || (myButtons[8].getText() == btnText && myButtons[0].getText() == btnText && myButtons[4].getText() == btnText))
        {
            Toast.makeText(this, btnText + " is the winner!", Toast.LENGTH_SHORT).show();

            for(int i = 0; i < myButtons.length; i++){
                myButtons[i].setEnabled(false);//setting all buttons enabled to false if game won
            }//end of for loop

        }//end of if statement
        else{
            cat();

            counter++;
        }//end of else statement

    }//end of btnNineHandler

}//end of Class
