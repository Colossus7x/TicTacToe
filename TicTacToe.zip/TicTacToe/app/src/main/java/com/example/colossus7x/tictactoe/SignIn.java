package com.example.colossus7x.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Colossus7x on 4/30/2017.
 */

public final class SignIn extends AppCompatActivity {
    Button btnSubmit;

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private SignIn() {}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this happens once user has submitted information
                Thread myThread = new Thread(){
                    @Override
                    public void run() {
                        try{
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                };
                myThread.start();
            }
        });

    }//end of onCreate
}
